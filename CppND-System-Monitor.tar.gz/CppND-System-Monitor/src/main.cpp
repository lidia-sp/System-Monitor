#include "ncurses_display.h"
#include "system.h"

#include "linux_parser.h"
#include "format.h"
#include <numeric>

int main() {
  System system;
  
 //Testing what Processor::Utilisation() returns
 /*  const std::vector<int> cpu_times1 = LinuxParser::CpuUtilization();
  int total_time1{0}, total_time2{0};
 
   int idle_time1 = cpu_times1[3];
    for (int i:cpu_times1){
    total_time1 = total_time1+i;
     std::cout<<" "<<i<< " " <<total_time1;
  }
  std::cout<<"accumulate: "<<total_time1;
  sleep(1);
  const std::vector<int> cpu_times2 = LinuxParser::CpuUtilization();
  int idle_time2 = cpu_times2[3];
  for (int i:cpu_times2){
    total_time2 += i;
  }

  const float idle_time_delta = (float)idle_time2 - (float)idle_time1;
  const float total_time_delta = (float)total_time2 - (float)total_time1;
  std::cout<<" result: "<< (1.0 - idle_time_delta / total_time_delta);*/

//Testing class system  
 /*std::cout<<" \n uptime: "<<system.UpTime();
  std::cout<<"\n Kernel:"<<system.Kernel();
  std::cout<<"\n memory:"<<system.MemoryUtilization();
  std::cout<<"\n total processes:"<<system.TotalProcesses();
  std::cout<<"\n running processes:"<<system.RunningProcesses(); 
   std::cout<<"\n Uptime:"<<system.UpTime() << "   " <<Format::ElapsedTime(system.UpTime());
  for (auto i:LinuxParser::CpuUtilization()){
    std::cout<<"  "<<i;
  }
 //Testing class Process
/* std::cout<<"Pid"<< system.Processes()[0].Pid();
  std::cout<<"User "<< system.Processes()[0].User();
  std::cout<<"Ram"<< system.Processes()[0].Ram();
  std::cout<<"\n UpTime"<< system.Processes()[0].UpTime();
  std::cout<<"\n CPU"<< system.Processes()[0].CpuUtilization();
  std::cout<<"\n"; */
  
  
  
NCursesDisplay::Display(system);
}