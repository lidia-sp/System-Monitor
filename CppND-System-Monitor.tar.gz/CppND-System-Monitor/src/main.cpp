#include "ncurses_display.h"
#include "system.h"

#include "linux_parser.h"
#include "format.h"


int main() {
  System system;
  
 /*std::cout<<" uptime: "<<system.UpTime();
  std::cout<<"\n Kernel:"<<system.Kernel();
  std::cout<<"\n memory:"<<system.MemoryUtilization();
  std::cout<<"\n total processes:"<<system.TotalProcesses();
  std::cout<<"\n running processes:"<<system.RunningProcesses(); 
   std::cout<<"\n Uptime:"<<system.UpTime() << "   " <<Format::ElapsedTime(system.UpTime());*/
   
NCursesDisplay::Display(system);
}