#include "processor.h"
#include <dirent.h>
#include <unistd.h>
#include <string>
#include <vector>
#include "linux_parser.h"
#include <numeric>

// TODO: Return the aggregate CPU utilization
float Processor::Utilization() { 

int previous_idle_time=0, previous_total_time=0;
for (int idle_time, total_time; get_cpu_times(idle_time, total_time); sleep(1)) {
  const float idle_time_delta = idle_time - previous_idle_time;
  const float total_time_delta = total_time - previous_total_time;
  const float utilization = (1.0 - idle_time_delta / total_time_delta);
  previous_idle_time = idle_time;
  previous_total_time = total_time;
}    
  return utilization; 
}
  
 bool get_cpu_times(int &idle_time, int &total_time) {
    const std::vector<int> cpu_times = LinuxParser::CpuUtilization();
    idle_time = cpu_times[3];
    total_time = std::accumulate(cpu_times.begin(), cpu_times.end(), 0);
    return true;
}